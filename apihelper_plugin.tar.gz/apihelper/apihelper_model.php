<?php
class ApihelperModel extends AppModel{
}
?>