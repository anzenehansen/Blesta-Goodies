<?php
class ldapauthModel extends AppModel {

        /**
         * Constructor
         */
        public function __construct() {
                parent::__construct();
        }
}
?>
