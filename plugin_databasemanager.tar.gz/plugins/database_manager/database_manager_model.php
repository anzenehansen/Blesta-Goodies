<?php
class databasemanagerModel extends AppModel {

        /**
         * Constructor
         */
        public function __construct() {
                parent::__construct();
        }
}
?>

