Multi-Company Login
====================

This plugin allows clients of those running Blesta in a multi-company environment to manage each profile.

Installation
-------------
Just place the "multi_company_login" folder into your Blesta's plugin directory then log in as a staff member who can install plugins and install it like any other plugin.  Currently there is no management for the plugin.

How It Works
-------------
The user can log in with either username or email address (though accounts in all companies must have the same primary email).  A new menu item is displayed on the user's menu.  When they click that link they are taken to a page where they can choose which company to switch to without having to log in.

Users are also able to switch back by going to the same page.
