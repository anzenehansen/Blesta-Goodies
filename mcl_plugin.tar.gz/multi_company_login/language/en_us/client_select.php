<?php
$lang["ClientSelect.switch_button"] = "Switch Company";
$lang["ClientSelect.overview"] = "If your account (based on email) is a part of any other companies you can choose to switch to your profile and view your account details.";
$lang["ClientSelect.directions"] = "Just select the company name from the dropdown list and click \"".$lang["ClientSelect.switch_button"]."\". If you wish to switch back just come back here.";
?>